package com.utd.MaximumWeightedMatching;


class test1 {

	public int a;
}

public class Test {

	public static void main(String[] args) {
		//
		//		double d = 1.0;
		//		Integer n = 1;
		//		for(int i=1;i<100;i++)
		//			if(!((double) n == d))
		//				System.out.println("Wrong OP");


		test1 a = new test1();

		create(a);

		System.out.println(a.a);
		//

	}

	private static void create(test1 a) {
		// TODO Auto-generated method stub
		//		a=new test1();
		a.a = 1;
	}

}
