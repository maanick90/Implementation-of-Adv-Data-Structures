package com.utd.MaximumWeightedMatching;


public class PrintClass {

	public static void PrintGraph(Graph root) {
		System.out.println("\n\n\n------------- Printing the graph --------------\n");
		System.out.println(root.nodesList);
		System.out.println(root.edgesList);
		for(Node node : root.nodesList)
			System.out.println("For node : " + node + " >> " + node.adjListEdges);
	}

	public static void PrintLabelling(Graph root) {

		System.out.println("\n\n\n------------ Printing Labels -----------\n");
		for(Node node : root.nodesList)
			System.out.println(node.id + " >> label = " + node.L);
	}

	public static void PrintZeroGraph(Graph graph) {

		System.out.println("\n\n\n------------ Printing Zero Graph-----------\n");
		System.out.println(graph.zeroGraphNodes);
		System.out.println(graph.zeroGraphEdges);
	}

	public static void PrintFreeNodes(Graph graph) {
		// First return the free node in the hungarian tree
		System.out.println("\n\n\n------------ Printing Free Nodes in ZG-----------\n");
		for(Node node : graph.zeroGraphNodes) 				// blossom nodes are also added to zeroGraphNodes
			if(node.mate == null && node.blossomParent.equals(node))					// nodes inside the blossom should not be included
				System.out.println("ZG Free Node = " + node + " >> " + node.mate);
		for(Node node : graph.nodesList)
			if(node.mate == null && node.blossomParent.equals(node))						// nodes inside the blossom should not be included
				System.out.println("Free Node = " + node + " >> " + node.mate);
	}

	public static void PrintMaximalMatching(Graph graph) {

		System.out.println("\n\n\n------------ Printing Maximal Matching Nodes -----------\n");
		for(Node node : graph.nodesList)
			System.out.println(node + " & Mate = " + node.mate);
	}

	public static void PrintAugmentingPath(Node u) {

		System.out.println("\n\n\n------------ Printing Augmenting Path -----------\n");
		while(u != null) {
			System.out.println(u + " and Parent: " + u.parent + " and Outer Node = " + u.outerNode);
			u = u.parent;
		}

	}

	public static void PrintCompleteNodeDetails(Node blossomNode) {

		System.out.println("\n\n\n------------ Printing Complete Node details-----------\n");
		System.out.println("Id : " + blossomNode.id);
		System.out.println("Adj List Edges : " + blossomNode.adjListEdges);
		System.out.println("Label : " + blossomNode.L);
		System.out.println("Mate : " + blossomNode.mate);
		System.out.println("OuterNode : " + blossomNode.outerNode);
		System.out.println("Parent : " + blossomNode.parent);
		System.out.println("ZeroAdjEdges : " + blossomNode.zeroAdjEdges);
		System.out.println("Blossom Parent : " + blossomNode.blossomParent);
		System.out.println("Blossom Child Nodes : " + blossomNode.blossomChilds);

	}

}
