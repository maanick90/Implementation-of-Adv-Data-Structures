package com.utd.Project10;

public class Kruskal {

	public static MSTTree RunKruskal(Graph root) {

			/*
			 * 1) MakeSet(u)
			 * 2) FindParent(u)
			 * 3) Union(u,v)
			 */
			
			MSTTree tree;
			Node ra, rb;
			
			for(Node node : root.nodesList)
				MakeSet(node);
			
			if(root.edgesList != null)
				for(Edge edge : root.edgesList) {
					ra = Find(edge.a);
					rb = Find(edge.b);
					if(ra != rb) {
						tree.addToMST(node, edge);
					}
				}
			
	}

	private static void MakeSet(Node node) {

		node.
		
	}
	
}
