package com.utd.Project10;

import java.util.LinkedList;
import java.util.List;

public class MSTTree {
	
	public List<Edge> treeMSTEdgesList;
	

	public MSTTree() {
		treeMSTEdgesList = new LinkedList<Edge>();
	}
	
	public void addToMST(Node node, Edge edge) {
		treeMSTEdgesList.add(edge);
		node.MSTEdge.add(edge);
	}
	
	@Override
	public String toString() {
		for(Edge edge : treeMSTEdgesList)
			System.out.println(edge);
		return "";
	}
}
